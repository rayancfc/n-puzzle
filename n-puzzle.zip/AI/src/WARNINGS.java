
public @interface WARNINGS {

}
